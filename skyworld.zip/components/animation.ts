import gsap from 'gsap';
import ScrollTrigger from 'gsap/ScrollTrigger';

export { gsap, ScrollTrigger };
